# Vishwas Jewellers — Order Book (installable PWA)

This folder turns your single `.html` app into a real installable app
(a Progressive Web App / PWA). It adds:

- `manifest.json` — tells the browser the app's name, icon, and that it
  should open full-screen, without browser address bar/tabs.
- `sw.js` — a service worker that caches the app so it opens instantly and
  works fully offline once installed.
- `icons/` — app icons generated from your Vishwas Jewellers logo.
- `index.html` — your original app, with the manifest, icons and the
  service worker wired in.

## Why you need to host it somewhere

A PWA can only be installed from `https://` (or `http://localhost`).
Opening the file directly from your phone's file manager (the
`content://...` URL you saw) can never trigger an install — there is no
web server, so the browser has nothing to treat as "a site."

You do **not** need a paid host. Any of these give you a free `https://`
address in a few minutes:

### Option A — GitHub Pages (recommended, free, permanent link)
1. Create a free GitHub account if you don't have one, and create a new
   repository (e.g. `vishwas-jewellers-app`).
2. Upload all 4 items in this folder — `index.html`, `manifest.json`,
   `sw.js`, and the whole `icons` folder — keeping this exact folder
   structure.
3. In the repo, go to **Settings → Pages**, set Source to your main
   branch, and save.
4. GitHub gives you a link like
   `https://yourusername.github.io/vishwas-jewellers-app/`. Open that link
   on your phone.

### Option B — Netlify Drop (fastest, no account needed to try it)
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page.
3. You instantly get an `https://something.netlify.app` link.
   (Create a free account to make the link permanent instead of temporary.)

## Installing it once hosted
1. Open the `https://...` link on your phone in Chrome (or your default
   browser).
2. You'll either see an automatic "Install app" banner, or you can tap the
   new **⬇ Install app** button added to the sidebar of the dashboard, or
   use the browser's menu → "Install app" / "Add to Home screen."
3. The app icon appears on your home screen. Opening it launches full
   screen, with no address bar, and works offline — your orders stay saved
   on that device exactly as before (IndexedDB), independent of hosting.

## Updating the app later
If you (or I) change `index.html` in the future, open `sw.js` and bump
the version string at the top (`vishwas-v1` → `vishwas-v2`, etc.) before
re-uploading. That's what tells the service worker to fetch the new
version instead of serving the old cached one.
